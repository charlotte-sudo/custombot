import os
import modal

app = modal.App()

@app.function(secrets=[modal.Secret.from_name("my-custom-secret-2")])
def my_function():
    api_key = os.environ.get("OPENAI_API_KEY")
    print(api_key)  # This should print your API key

if __name__ == "__main__":
    app.run(my_function)

